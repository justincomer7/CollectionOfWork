package com.example.administrator.mal_locator;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.awt.font.TextAttribute;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    Button steal_1;
    BroadcastReceiver receiver;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.stolen);
        steal_1 = (Button) findViewById(R.id.steal);

        if (receiver == null) {
            receiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {

                    textView.append("\n" + intent.getExtras().get("location"));
                }
            };
        }
        registerReceiver(receiver, new IntentFilter("update"));

        steal_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent();
                String pkg = "com.example.administrator.location";
                String cls = "com.example.administrator.location.GPS_Service";
                i.setComponent(new ComponentName(pkg, cls));
                startService(i);
            }
        });
    }



}
