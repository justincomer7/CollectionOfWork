package com.example.administrator.intededreciever;

import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.security.SecureRandom;

import static android.content.Intent.ACTION_DEFAULT;

public class MainActivity extends AppCompatActivity {

    EditText pass;
    TextView info;

    Button get;
    Button set;
    String password;

    IntentFilter filter;
    MyReceiver reciever;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        get = (Button) findViewById(R.id.Get);

        info = (TextView) findViewById(R.id.display);

        setPass();

        /*For when no password - displays that the intent
        still reaches the intended target, while being intercepted
        */

        //comment out when adding security
        filter = new IntentFilter(ACTION_DEFAULT);
        reciever = new MyReceiver();
        registerReceiver(reciever, filter);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void setPass() {
        password = randomString(10);

        Toast.makeText(getApplicationContext(), "Password Set: " + password, Toast.LENGTH_LONG).show();
        /*for when security measure 1 is in place


        //uncomment when adding security
        filter = new IntentFilter(password);
        reciever = new MyReceiver();
        registerReceiver(reciever, filter);*/
    }


    public void setGet(View view){
        info = (TextView) findViewById(R.id.display);
        info.setText(reciever.getInfo());
    }

    public String randomString(int len){
        final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        SecureRandom rnd = new SecureRandom();

        StringBuilder sb = new StringBuilder( len );
        for( int i = 0; i < len; i++ )
            sb.append( AB.charAt( rnd.nextInt(AB.length()) ) );
        return sb.toString();
    }
}
