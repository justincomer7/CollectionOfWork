package com.example.administrator.intededreciever;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.TextView;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {

    Context context;
    String acc = "";
    TextView account;

    public String getInfo(){
        return acc;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        this.context = context;
        acc = intent.getStringExtra("Acc");
    }
}
