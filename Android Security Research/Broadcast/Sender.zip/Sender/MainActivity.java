package com.example.administrator.snrprjct_sender;

import android.Manifest;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    String num;
    String password;
    EditText enter;
    Intent i = new Intent();
    EditText pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void getKey(View view) {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.example.administrator.intededreciever");
        if(launchIntent != null){
            startActivity(launchIntent);
        }
    }

    public void sendBroadcast(View view){
        enter= (EditText) findViewById(R.id.Input);
        pass = (EditText) findViewById(R.id.Password);

        num = enter.getText().toString();
        password = pass.getText().toString();


        i.putExtra("Acc", num);

        //comment this out when adding security
        i.setAction(i.ACTION_DEFAULT);

        //Security Measure 1
        //i.setAction(password);
        //Uses a String as a key

        //Security Measure 2
        //i.setPackage("com.example.administrator.intededreciever");
        //Explicitly states the desitination of the intent

        //Security Measure 3
        /*<uses-permission android:name="com.customPerm"/>
        *********copy to manisfest file of reciever***********
        <permission android:name="com.customPerm"/>
        *********copy to manifest file of sender**********
        "com.customPerm"
        *********add as second argument in sendBroadcast**************
        gives permissions for the app to request info and cannot be manipulated by the user,
        protects them from themselves, and in new versions of hte operating system prompts the user to
        allow them to send the info*/

        sendBroadcast(i);
    }


}
