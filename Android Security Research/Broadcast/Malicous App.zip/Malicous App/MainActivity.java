package com.example.administrator.unIntededreciever;

import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

import static android.content.Intent.ACTION_DEFAULT;

public class MainActivity extends AppCompatActivity {


    int num1;
    int num2;
    int num3;
    int Answer;

    TextView Num1;
    TextView Num2;

    EditText Ans;

    Button New;
    Button check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        IntentFilter filter = new IntentFilter(ACTION_DEFAULT);
        //IntentFilter filter = new IntentFilter("yeet");
        BroadcastReceiver receiver = new MyReceiver();
        registerReceiver(receiver, filter);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Num1 = (TextView) findViewById(R.id.num1);
        Num2 = (TextView) findViewById(R.id.num2);

        Ans = (EditText) findViewById(R.id.answer);

        New = (Button) findViewById(R.id.New);
        check = (Button) findViewById(R.id.Check);

        New.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random rand = new Random();

                num1 = rand.nextInt(20) + 1;
                num2 = rand.nextInt(20) + 1;
                num3 = num1 + num2;

                String val1 = String.valueOf(num1);
                String val2 = String.valueOf(num2);

                Num1.setText(val1);
                Num2.setText(val2);

            }
        });

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String input = Ans.getText().toString();
                Answer = Integer.parseInt(input);
                if (Answer == num3)
                    Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(getApplicationContext(), "Incorrect", Toast.LENGTH_LONG).show();
            }
        });
    }
}